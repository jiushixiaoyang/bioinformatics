# Bioinformatics_data

Data for the Bioinformatics masters course @ University of Bristol

## Data sources

Covid-19 death data from https://data.humdata.org/dataset/novel-coronavirus-2019-ncov-cases.

Other data are simulations.

## Authors

Chris Clements